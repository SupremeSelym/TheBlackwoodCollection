﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Tripolygon.UModeler.UI;
using Tripolygon.UModelerX.Runtime;
using UnityEditor.ShortcutManagement;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor
{
    [ApplicationService(typeof(UMXShortcutProfileService))]
    sealed class UMXShortcutProfileService : ApplicationServiceBase
    {
        private const string UMXShortcutProfileId = "UModelerX-Shortcuts";

        // 이전 상태를 기억하지 않고 목표 상태를 매번 계산해서 적용한다.
        // 복원해야 할 값이 상수뿐이므로 도메인 리로드·에디터 강제 종료 후에도 항상 올바른 상태로 수렴한다.
        private bool isApplying;
        private bool hasLastState;
        private bool lastIsEnabled;
        private bool lastHasActiveObject;

#if UNITY_2023_2_OR_NEWER
        // 2023.2 부터는 발동 조건을 컨텍스트로 표현한다. 등록해 두지 않으면 슬롯이 영영 발동하지 않는다.
        private readonly UMXAltBlockContext altBlockContext = new UMXAltBlockContext();
#endif

        protected override void OnInitialize(bool isReloading, bool isPlaying)
        {
#if UNITY_2023_2_OR_NEWER
            ShortcutManager.RegisterContext(altBlockContext);
#endif
            ShortcutManager.instance.activeProfileChanged += ActiveProfileChanged;
            UMXShortcutQuery.Changed += UMXShortcutChanged;
            this.Application.Update += Application_Update;

            // 기동·리로드 시점은 언제나 UModelerX 비활성 상태이므로,
            // 여기서 목표 상태를 적용하는 것만으로 강제 종료·크래시 잔재가 복구된다.
            ApplyDesiredState();
        }

        protected override void OnRelease(bool isReloading)
        {
            this.Application.Update -= Application_Update;
            UMXShortcutQuery.Changed -= UMXShortcutChanged;
            ShortcutManager.instance.activeProfileChanged -= ActiveProfileChanged;
#if UNITY_2023_2_OR_NEWER
            ShortcutManager.UnregisterContext(altBlockContext);
#endif

            if (isReloading == false)
            {
                // 정상 종료 시 미리 치운다. 실패하더라도 다음 기동의 OnInitialize 가 복구한다.
                ApplyState(false, false);
            }
        }

        private void Application_Update(object sender, ApplicationUpdateEventArgs e)
        {
            bool isEnabled = UMXShortcutQuery.IsEnabled;
            bool hasActiveObject = IEditorObjectEvents.ActiveObject != null;
            if (hasLastState == true && lastIsEnabled == isEnabled && lastHasActiveObject == hasActiveObject)
            {
                return;
            }
            hasLastState = true;
            lastIsEnabled = isEnabled;
            lastHasActiveObject = hasActiveObject;
            ApplyState(isEnabled, hasActiveObject);
        }

        // 사용자가 Preferences 에서 단축키를 바꾸면 흡수해야 할 Alt 조합 자체가 달라지므로 다시 적용한다.
        private void UMXShortcutChanged(object sender, System.EventArgs e)
        {
            if (isApplying == true)
            {
                return;
            }
            ApplyDesiredState();
        }

        // 사용자가 Shortcuts 창에서 프로파일을 직접 바꾸면 새 프로파일에 목표 상태를 다시 적용한다.
        private void ActiveProfileChanged(ActiveProfileChangedEventArgs args)
        {
            if (isApplying == true)
            {
                return;
            }
            ApplyDesiredState();
        }

        private void ApplyDesiredState()
        {
            bool isEnabled = UMXShortcutQuery.IsEnabled;
            bool hasActiveObject = IEditorObjectEvents.ActiveObject != null;
            hasLastState = true;
            lastIsEnabled = isEnabled;
            lastHasActiveObject = hasActiveObject;
            ApplyState(isEnabled, hasActiveObject);
        }

        private void ApplyState(bool isEnabled, bool hasActiveObject)
        {
            if (isApplying == true)
            {
                return;
            }

            isApplying = true;
            try
            {
                var manager = ShortcutManager.instance;
                var keysToBlock = CollectAltKeysToBlock(isEnabled, hasActiveObject);
                if (keysToBlock.Count > 0)
                {
                    // 읽기 전용 프로파일(Default)에는 바인딩을 쓸 수 없어 이 경우에만 전용 프로파일로 전환한다.
                    // Default 는 오버라이드를 가질 수 없으므로 전환해도 잃는 사용자 설정이 없다.
                    // 쓰기 가능한 프로파일이면 전환하지 않고 그대로 사용해 사용자 단축키 설정을 보존한다.
                    if (manager.IsProfileReadOnly(manager.activeProfileId) == true)
                    {
                        EnsureUMXProfileExists();
                        manager.activeProfileId = UMXShortcutProfileId;
                    }
                    SetAltBlockBindings(keysToBlock);
                }
                else if (manager.activeProfileId == UMXShortcutProfileId)
                {
                    // 전용 프로파일은 읽기 전용 프로파일에서만 진입하므로 복귀 대상이 항상 Default 다.
                    // 복귀 대상이 상수라 별도로 기억해 둘 상태가 없다.
                    manager.activeProfileId = ShortcutManager.defaultProfileId;
                }
                else
                {
                    SetAltBlockBindings(keysToBlock);
                }
            }
            finally
            {
                isApplying = false;
            }
        }

        /// <summary>
        /// 흡수해야 할 Alt+글자 조합을 모읍니다. 키는 A~Z 글자, 값은 그 글자에 넣을 모디파이어입니다.
        /// UMX 가 실제로 쓰는 조합만 대상입니다. 쓰지 않는 Alt+F 등은 잡지 않고 Unity 메뉴에 그대로 둡니다.
        /// UModelerX 가 꺼져 있으면 아무것도 잡지 않습니다.
        /// </summary>
        private static Dictionary<KeyCode, ShortcutModifiers> CollectAltKeysToBlock(bool isEnabled, bool hasActiveObject)
        {
            var result = new Dictionary<KeyCode, ShortcutModifiers>();
            if (isEnabled == false)
            {
                return result;
            }

#if UNITY_2023_2_OR_NEWER
            // UMXAltBlockContext 가 "오브젝트 편집 중" 을 판정하므로 바인딩은 오브젝트 선택 상태와
            // 무관하게 고정한다. 오브젝트를 선택·해제할 때마다 프로파일 파일을 다시 쓰는 일이 없어진다.
            bool includeEditingScope = true;
#else
            // 커스텀 컨텍스트를 만들 수 없는 버전이라 "오브젝트 편집 중" 조건을 바인딩 on/off 로 흉내 낸다.
            bool includeEditingScope = hasActiveObject;
#endif

            UMXShortcutQuery.CollectAltLetterCombos(globalOnly: includeEditingScope == false, result);
            return result;
        }

        // 전용 프로파일은 Alt 메뉴 차단 단축키만 담는다.
        // 엔트리가 없는 단축키는 Unity 기본 바인딩으로 폴백되므로 Default 를 복제할 필요가 없다.
        private static void EnsureUMXProfileExists()
        {
            var manager = ShortcutManager.instance;
            if (manager.GetAvailableProfileIds().Contains(UMXShortcutProfileId) == false)
            {
                manager.CreateProfile(UMXShortcutProfileId);
            }
        }

        // 현재 활성 프로파일의 A~Z 흡수 슬롯을 목표 상태로 맞춘다.
        // keysToBlock 에 없는 글자는 빈 바인딩으로 되돌려 Unity 기본 동작을 돌려준다.
        private static void SetAltBlockBindings(Dictionary<KeyCode, ShortcutModifiers> keysToBlock)
        {
            var manager = ShortcutManager.instance;
            if (manager.IsProfileReadOnly(manager.activeProfileId) == true)
            {
                return;
            }

            var availableIds = new HashSet<string>(manager.GetAvailableShortcutIds());
            for (var keyCode = KeyCode.A; keyCode <= KeyCode.Z; keyCode++)
            {
                var shortcutId = UMXMenuBlockShortcuts.GetShortcutId(keyCode);
                if (availableIds.Contains(shortcutId) == false)
                {
                    continue;
                }
                var desired = keysToBlock.TryGetValue(keyCode, out var shortcutMods) == true
                    ? new ShortcutBinding(new KeyCombination(keyCode, shortcutMods))
                    : ShortcutBinding.empty;
                var current = manager.GetShortcutBinding(shortcutId);
                if (AreBindingsEqual(current, desired) == true)
                {
                    // 값이 이미 같으면 프로파일 파일 write 자체가 일어나지 않는다.
                    continue;
                }
                TryRebindShortcut(shortcutId, desired);
            }
        }

        private static bool AreBindingsEqual(ShortcutBinding a, ShortcutBinding b)
        {
            var seqA = a.keyCombinationSequence;
            var seqB = b.keyCombinationSequence;
            using (var itA = seqA.GetEnumerator())
            using (var itB = seqB.GetEnumerator())
            {
                while (true)
                {
                    bool hasA = itA.MoveNext();
                    bool hasB = itB.MoveNext();
                    if (hasA != hasB)
                    {
                        return false;
                    }
                    if (hasA == false)
                    {
                        return true;
                    }
                    if (itA.Current.Equals(itB.Current) == false)
                    {
                        return false;
                    }
                }
            }
        }

        // ShortcutManager.RebindShortcut 내부에서 .shortcut 프로파일 JSON 을 File.WriteAllText 로 동기 저장한다.
        // 백신/인덱서/클라우드 동기화가 같은 파일을 1~10ms 잡고 있으면 IOException(Sharing violation) 이 날 수 있어
        // 짧은 backoff 로 재시도한다.
        private static void TryRebindShortcut(string shortcutId, ShortcutBinding binding)
        {
            const int MaxRetries = 5;
            for (int attempt = 0; attempt < MaxRetries; attempt++)
            {
                try
                {
                    ShortcutManager.instance.RebindShortcut(shortcutId, binding);
                    return;
                }
                catch (IOException)
                {
                    if (attempt == MaxRetries - 1)
                    {
                        return;
                    }
                    Thread.Sleep(20 * (attempt + 1));
                }
            }
        }
    }
}
