﻿using UnityEditor.ShortcutManagement;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor
{
#if UNITY_2023_2_OR_NEWER
    /// <summary>
    /// 흡수용 단축키가 발동할 조건입니다. UModeler 오브젝트를 편집 중일 때만 활성입니다.
    /// 2023.2 부터 IShortcutContext 가 public 이라 이 조건을 그대로 표현할 수 있어,
    /// 오브젝트 선택 상태에 따라 바인딩을 넣고 빼는(=프로파일 파일 write) 일이 필요 없습니다.
    ///
    /// 창은 가리지 않습니다. UMX 단축키는 씬뷰 밖에 포커스가 있어도 UMXShortcutInputService 의
    /// globalEventHandler 경로로 동작하고, 경고음도 그때 똑같이 나기 때문입니다.
    /// </summary>
    sealed class UMXAltBlockContext : IShortcutContext
    {
        public bool active
        {
            get { return UMXShortcutQuery.IsEnabled && IEditorObjectEvents.ActiveObject != null; }
        }
    }
#endif

    /// <summary>
    /// Alt+글자 조합을 Unity 단축키로 흡수하기 위한 빈 단축키입니다. A~Z 슬롯을 미리 선언해 두고,
    /// 실제 바인딩은 <see cref="UMXShortcutProfileService"/> 가 런타임에 넣고 뺍니다.
    ///
    /// 흡수가 필요한 이유는 두 가지입니다.
    ///  - Alt+글자가 Unity 단축키에 잡혀 있지 않으면 이벤트가 네이티브까지 내려가 윈도우 경고음이 울립니다.
    ///    IMGUI 의 evt.Use() 는 네이티브 메시지 루프보다 늦게 실행되어 이 소리를 막지 못합니다.
    ///  - Alt+F 등 윈도우 메뉴 니모닉 글자에 UMX 단축키가 걸려 있으면 상단 메뉴까지 열려 버립니다.
    ///
    /// 어트리뷰트에는 기본 바인딩을 주지 않습니다. 기본값을 주면 UModeler 를 쓰지 않는 동안에도
    /// 해당 Alt 조합을 계속 잡아 Unity 기본 동작을 방해합니다.
    ///
    /// "UModeler 오브젝트 편집 중" 이라는 발동 조건은 2023.2 이상에서는 <see cref="UMXAltBlockContext"/> 가,
    /// 그 미만에서는 <see cref="UMXShortcutProfileService"/> 의 바인딩 on/off 가 담당합니다.
    /// 2022.3 의 IShortcutToolContext 는 internal 이라 같은 조건을 컨텍스트로 만들 수 없습니다.
    /// </summary>
    static class UMXMenuBlockShortcuts
    {
        /// <summary>단축키 ID 접두사. 기존 사용자 프로파일과의 호환을 위해 이름을 유지합니다.</summary>
        internal const string ShortcutIdPrefix = "UModeler X/Menu Block/Alt+";

        /// <summary>A~Z 글자에 대응하는 흡수용 단축키 ID 를 반환합니다. 범위 밖이면 null 입니다.</summary>
        internal static string GetShortcutId(KeyCode keyCode)
        {
            if (keyCode < KeyCode.A || keyCode > KeyCode.Z)
            {
                return null;
            }

            return ShortcutIdPrefix + (char)('A' + (keyCode - KeyCode.A));
        }

#if UNITY_2023_2_OR_NEWER
        [Shortcut(ShortcutIdPrefix + "A", typeof(UMXAltBlockContext))] static void MenuBlock_AltA() { }
        [Shortcut(ShortcutIdPrefix + "B", typeof(UMXAltBlockContext))] static void MenuBlock_AltB() { }
        [Shortcut(ShortcutIdPrefix + "C", typeof(UMXAltBlockContext))] static void MenuBlock_AltC() { }
        [Shortcut(ShortcutIdPrefix + "D", typeof(UMXAltBlockContext))] static void MenuBlock_AltD() { }
        [Shortcut(ShortcutIdPrefix + "E", typeof(UMXAltBlockContext))] static void MenuBlock_AltE() { }
        [Shortcut(ShortcutIdPrefix + "F", typeof(UMXAltBlockContext))] static void MenuBlock_AltF() { }
        [Shortcut(ShortcutIdPrefix + "G", typeof(UMXAltBlockContext))] static void MenuBlock_AltG() { }
        [Shortcut(ShortcutIdPrefix + "H", typeof(UMXAltBlockContext))] static void MenuBlock_AltH() { }
        [Shortcut(ShortcutIdPrefix + "I", typeof(UMXAltBlockContext))] static void MenuBlock_AltI() { }
        [Shortcut(ShortcutIdPrefix + "J", typeof(UMXAltBlockContext))] static void MenuBlock_AltJ() { }
        [Shortcut(ShortcutIdPrefix + "K", typeof(UMXAltBlockContext))] static void MenuBlock_AltK() { }
        [Shortcut(ShortcutIdPrefix + "L", typeof(UMXAltBlockContext))] static void MenuBlock_AltL() { }
        [Shortcut(ShortcutIdPrefix + "M", typeof(UMXAltBlockContext))] static void MenuBlock_AltM() { }
        [Shortcut(ShortcutIdPrefix + "N", typeof(UMXAltBlockContext))] static void MenuBlock_AltN() { }
        [Shortcut(ShortcutIdPrefix + "O", typeof(UMXAltBlockContext))] static void MenuBlock_AltO() { }
        [Shortcut(ShortcutIdPrefix + "P", typeof(UMXAltBlockContext))] static void MenuBlock_AltP() { }
        [Shortcut(ShortcutIdPrefix + "Q", typeof(UMXAltBlockContext))] static void MenuBlock_AltQ() { }
        [Shortcut(ShortcutIdPrefix + "R", typeof(UMXAltBlockContext))] static void MenuBlock_AltR() { }
        [Shortcut(ShortcutIdPrefix + "S", typeof(UMXAltBlockContext))] static void MenuBlock_AltS() { }
        [Shortcut(ShortcutIdPrefix + "T", typeof(UMXAltBlockContext))] static void MenuBlock_AltT() { }
        [Shortcut(ShortcutIdPrefix + "U", typeof(UMXAltBlockContext))] static void MenuBlock_AltU() { }
        [Shortcut(ShortcutIdPrefix + "V", typeof(UMXAltBlockContext))] static void MenuBlock_AltV() { }
        [Shortcut(ShortcutIdPrefix + "W", typeof(UMXAltBlockContext))] static void MenuBlock_AltW() { }
        [Shortcut(ShortcutIdPrefix + "X", typeof(UMXAltBlockContext))] static void MenuBlock_AltX() { }
        [Shortcut(ShortcutIdPrefix + "Y", typeof(UMXAltBlockContext))] static void MenuBlock_AltY() { }
        [Shortcut(ShortcutIdPrefix + "Z", typeof(UMXAltBlockContext))] static void MenuBlock_AltZ() { }
#else
        [Shortcut(ShortcutIdPrefix + "A")] static void MenuBlock_AltA() { }
        [Shortcut(ShortcutIdPrefix + "B")] static void MenuBlock_AltB() { }
        [Shortcut(ShortcutIdPrefix + "C")] static void MenuBlock_AltC() { }
        [Shortcut(ShortcutIdPrefix + "D")] static void MenuBlock_AltD() { }
        [Shortcut(ShortcutIdPrefix + "E")] static void MenuBlock_AltE() { }
        [Shortcut(ShortcutIdPrefix + "F")] static void MenuBlock_AltF() { }
        [Shortcut(ShortcutIdPrefix + "G")] static void MenuBlock_AltG() { }
        [Shortcut(ShortcutIdPrefix + "H")] static void MenuBlock_AltH() { }
        [Shortcut(ShortcutIdPrefix + "I")] static void MenuBlock_AltI() { }
        [Shortcut(ShortcutIdPrefix + "J")] static void MenuBlock_AltJ() { }
        [Shortcut(ShortcutIdPrefix + "K")] static void MenuBlock_AltK() { }
        [Shortcut(ShortcutIdPrefix + "L")] static void MenuBlock_AltL() { }
        [Shortcut(ShortcutIdPrefix + "M")] static void MenuBlock_AltM() { }
        [Shortcut(ShortcutIdPrefix + "N")] static void MenuBlock_AltN() { }
        [Shortcut(ShortcutIdPrefix + "O")] static void MenuBlock_AltO() { }
        [Shortcut(ShortcutIdPrefix + "P")] static void MenuBlock_AltP() { }
        [Shortcut(ShortcutIdPrefix + "Q")] static void MenuBlock_AltQ() { }
        [Shortcut(ShortcutIdPrefix + "R")] static void MenuBlock_AltR() { }
        [Shortcut(ShortcutIdPrefix + "S")] static void MenuBlock_AltS() { }
        [Shortcut(ShortcutIdPrefix + "T")] static void MenuBlock_AltT() { }
        [Shortcut(ShortcutIdPrefix + "U")] static void MenuBlock_AltU() { }
        [Shortcut(ShortcutIdPrefix + "V")] static void MenuBlock_AltV() { }
        [Shortcut(ShortcutIdPrefix + "W")] static void MenuBlock_AltW() { }
        [Shortcut(ShortcutIdPrefix + "X")] static void MenuBlock_AltX() { }
        [Shortcut(ShortcutIdPrefix + "Y")] static void MenuBlock_AltY() { }
        [Shortcut(ShortcutIdPrefix + "Z")] static void MenuBlock_AltZ() { }
#endif
    }
}
