using Unity.Burst;
using Unity.Jobs;
using UnityEditor;

namespace Tripolygon.UModelerX.Editor
{
    /// <summary>
    /// 커널을 감싸는 버스트 진입점(병렬).
    ///
    /// 이 파일이 소스로 배포되는 어셈블리에 있는 것이 핵심입니다 — 버스트는 유니티가 지금
    /// 컴파일하는 어셈블리만 진입점 탐색 대상으로 삼으므로, 프리컴파일 DLL 안의
    /// [BurstCompile] 잡은 등록되지 않고 영구히 관리 폴백으로 돕니다. 진입점만 여기 두고
    /// 본문은 DLL 쪽 커널에 두면, 버스트가 호출 그래프를 따라 DLL 의 IL 까지 네이티브로
    /// 컴파일합니다.
    ///
    /// T 제약이 struct 라 kernel.Execute 호출은 정적으로 확정되어 인라인됩니다.
    /// </summary>
    [BurstCompile(CompileSynchronously = true)]
    public struct UMXParallelKernelJob<T> : IJobParallelFor where T : struct, IUMXParallelKernel
    {
        public T kernel;

        public void Execute(int index)
        {
            this.kernel.Execute(index);
        }
    }

    /// <summary>커널을 감싸는 버스트 진입점(단일 스레드). <see cref="UMXParallelKernelJob{T}"/> 와 같은 이유로 존재합니다.</summary>
    [BurstCompile(CompileSynchronously = true)]
    public struct UMXSingleKernelJob<T> : IJob where T : struct, IUMXSingleKernel
    {
        public T kernel;

        public void Execute()
        {
            this.kernel.Execute();
        }
    }

    /// <summary>DLL 쪽에서 커널을 실행할 때 타는 경로. 잡 타입이 이 어셈블리에 있어 여기서 구현합니다.</summary>
    internal sealed class UMXBurstJobScheduler : IUMXJobScheduler
    {
        public void RunParallel<T>(in T kernel, int count) where T : struct, IUMXParallelKernel
        {
            new UMXParallelKernelJob<T> { kernel = kernel }.Run(count);
        }

        public JobHandle ScheduleParallel<T>(in T kernel, int count, int batch, JobHandle dependsOn = default)
            where T : struct, IUMXParallelKernel
        {
            return new UMXParallelKernelJob<T> { kernel = kernel }.Schedule(count, batch, dependsOn);
        }

        public void RunSingle<T>(in T kernel) where T : struct, IUMXSingleKernel
        {
            new UMXSingleKernelJob<T> { kernel = kernel }.Run();
        }

        public JobHandle ScheduleSingle<T>(in T kernel, JobHandle dependsOn = default) where T : struct, IUMXSingleKernel
        {
            return new UMXSingleKernelJob<T> { kernel = kernel }.Schedule(dependsOn);
        }
    }

    [InitializeOnLoad]
    internal static class UMXBurstJobSchedulerInstaller
    {
        static UMXBurstJobSchedulerInstaller()
        {
            UMXBurstJobBridge.Scheduler = new UMXBurstJobScheduler();
        }

        /// <summary>
        /// 쓰이는 커널 조합을 이 어셈블리 IL 에 박아 둡니다.
        ///
        /// 버스트는 어셈블리의 TypeSpec/MethodSpec 테이블과 필드 타입을 훑어 닫힌 제네릭을
        /// 찾습니다 — <b>메서드 본문 IL 은 보지 않습니다</b>. 그래서 본문에서 쓰는 것만으로는
        /// 부족하고(스케줄러의 UMXParallelKernelJob&lt;T&gt; 도 T 가 열린 채라 걸리지 않습니다),
        /// 커널마다 필드를 하나씩 선언해 닫힌 타입을 메타데이터에 남깁니다.
        /// 빠뜨리면 그 커널만 조용히 관리 폴백으로 돌므로, 커널을 추가하면 여기에도 추가해야 합니다.
        ///
        /// (com.unity.collections 의 [RegisterGenericJobType] 을 쓰지 않는 이유는
        ///  버스트만 있고 컬렉션즈가 없는 프로젝트에서도 동작해야 하기 때문입니다.)
        /// </summary>
#pragma warning disable 0169
        private static UMXParallelKernelJob<UMXBackupCollectBurst.UMXBackupNeighborhoodCollectKernel> pinUMXBackupNeighborhoodCollectKernel;
        private static UMXParallelKernelJob<UMXBrushBurst.UMXBrushMoveKernel> pinUMXBrushMoveKernel;
        private static UMXParallelKernelJob<UMXBrushBurst.UMXBrushPinchKernel> pinUMXBrushPinchKernel;
        private static UMXParallelKernelJob<UMXBrushBurst.UMXBrushFlattenKernel> pinUMXBrushFlattenKernel;
        private static UMXParallelKernelJob<UMXBrushBurst.UMXBrushStandardKernel> pinUMXBrushStandardKernel;
        private static UMXParallelKernelJob<UMXBrushBurst.UMXBrushSmoothGatherKernel> pinUMXBrushSmoothGatherKernel;
        private static UMXParallelKernelJob<UMXBrushBurst.UMXBrushSmoothScatterKernel> pinUMXBrushSmoothScatterKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhTriangleBoundsKernel> pinUMXBvhTriangleBoundsKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhMortonKernel> pinUMXBvhMortonKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhSortedIndexKernel> pinUMXBvhSortedIndexKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhLeafNodeKernel> pinUMXBvhLeafNodeKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhTopologyKernel> pinUMXBvhTopologyKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhBottomUpBoundsKernel> pinUMXBvhBottomUpBoundsKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhTriangleFaceIDKernel> pinUMXBvhTriangleFaceIDKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhRefitTriangleBoundsKernel> pinUMXBvhRefitTriangleBoundsKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhFaceHintClearKernel> pinUMXBvhFaceHintClearKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhLoopMapsKernel> pinUMXBvhLoopMapsKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhRectFacesKernel> pinUMXBvhRectFacesKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhCapsuleFacesKernel> pinUMXBvhCapsuleFacesKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvh4CollapseKernel> pinUMXBvh4CollapseKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhRadixHistogramKernel> pinUMXBvhRadixHistogramKernel;
        private static UMXParallelKernelJob<UMXBvhPickingBurst.UMXBvhRadixScatterKernel> pinUMXBvhRadixScatterKernel;
        private static UMXParallelKernelJob<UMXDataPackBurst.UMXVertexPoolScatterKernel> pinUMXVertexPoolScatterKernel;
        private static UMXParallelKernelJob<UMXDataPackBurst.UMXEdgePoolScatterKernel> pinUMXEdgePoolScatterKernel;
        private static UMXParallelKernelJob<UMXDataPackBurst.UMXLoopPoolScatterKernel> pinUMXLoopPoolScatterKernel;
        private static UMXParallelKernelJob<UMXDataPackBurst.UMXFacePoolScatterKernel> pinUMXFacePoolScatterKernel;
        private static UMXParallelKernelJob<UMXDataPackBurst.UMXFaceHolePoolScatterKernel> pinUMXFaceHolePoolScatterKernel;
        private static UMXParallelKernelJob<UMXDataPackBurst.UMXUVPoolScatterKernel> pinUMXUVPoolScatterKernel;
        private static UMXParallelKernelJob<UMXDataPackBurst.UMXColor32ToColorScatterKernel> pinUMXColor32ToColorScatterKernel;
        private static UMXParallelKernelJob<UMXEdgeCacheBurst.UMXEdgeSharpUpdateKernel> pinUMXEdgeSharpUpdateKernel;
        private static UMXParallelKernelJob<UMXEdgeCacheBurst.UMXOnlyEdgeMarkKernel> pinUMXOnlyEdgeMarkKernel;
        private static UMXParallelKernelJob<UMXEdgeCacheBurst.UMXQuadTriangulateKernel> pinUMXQuadTriangulateKernel;
        private static UMXParallelKernelJob<UMXEdgeCacheBurst.UMXFaceTriangulationCompareKernel> pinUMXFaceTriangulationCompareKernel;
        private static UMXParallelKernelJob<UMXEdgeCacheBurst.UMXCustomNormalHintMarkKernel> pinUMXCustomNormalHintMarkKernel;
        private static UMXParallelKernelJob<UMXElementHintBurst.UMXHintMarkAllKernel> pinUMXHintMarkAllKernel;
        private static UMXParallelKernelJob<UMXElementHintBurst.UMXHintClearAllKernel> pinUMXHintClearAllKernel;
        private static UMXParallelKernelJob<UMXFaceBatchCreateBurst.UMXElementOrderKeyKernel> pinUMXElementOrderKeyKernel;
        private static UMXParallelKernelJob<UMXFaceBatchCreateBurst.UMXRunStartMarkKernel> pinUMXRunStartMarkKernel;
        private static UMXParallelKernelJob<UMXFaceBatchCreateBurst.UMXRadialLinkKernel> pinUMXRadialLinkKernel;
        private static UMXParallelKernelJob<UMXFaceBatchCreateBurst.UMXDiskPairEmitKernel> pinUMXDiskPairEmitKernel;
        private static UMXParallelKernelJob<UMXFaceBatchCreateBurst.UMXDiskLinkKernel> pinUMXDiskLinkKernel;
        private static UMXParallelKernelJob<UMXFaceMaterialBurst.UMXFaceIndexSliceWriteKernel> pinUMXFaceIndexSliceWriteKernel;
        private static UMXParallelKernelJob<UMXIslandBurst.UMXUnionFindInitKernel> pinUMXUnionFindInitKernel;
        private static UMXParallelKernelJob<UMXIslandBurst.UMXUnionFindCompressKernel> pinUMXUnionFindCompressKernel;
        private static UMXParallelKernelJob<UMXIslandBurst.UMXUVIslandUnionKernel> pinUMXUVIslandUnionKernel;
        private static UMXParallelKernelJob<UMXIslandBurst.UMXIsolateUnionKernel> pinUMXIsolateUnionKernel;
        private static UMXParallelKernelJob<UMXIslandBurst.UMXIslandFaceRootKernel> pinUMXIslandFaceRootKernel;
        private static UMXParallelKernelJob<UMXIslandBurst.UMXIslandBoundsResetKernel> pinUMXIslandBoundsResetKernel;
        private static UMXParallelKernelJob<UMXIslandBurst.UMXUVIslandBoundsKernel> pinUMXUVIslandBoundsKernel;
        private static UMXParallelKernelJob<UMXMemCopyBurst.UMXChunkCopyKernel> pinUMXChunkCopyKernel;
        private static UMXParallelKernelJob<UMXMeshCacheBurst.UMXFacePlaneUpdateKernel> pinUMXFacePlaneUpdateKernel;
        private static UMXParallelKernelJob<UMXMeshCacheBurst.UMXLoopPositionGatherKernel> pinUMXLoopPositionGatherKernel;
        private static UMXParallelKernelJob<UMXMeshCacheBurst.UMXLoopColorGatherKernel> pinUMXLoopColorGatherKernel;
        private static UMXParallelKernelJob<UMXMeshCacheBurst.UMXLoopBoneWeightGatherKernel> pinUMXLoopBoneWeightGatherKernel;
        private static UMXParallelKernelJob<UMXMeshCacheBurst.UMXLoopUVGatherKernel> pinUMXLoopUVGatherKernel;
        private static UMXParallelKernelJob<UMXMeshCacheBurst.UMXOnlyVertexMarkKernel> pinUMXOnlyVertexMarkKernel;
        private static UMXParallelKernelJob<UMXMeshCacheBurst.UMXVertexNormalWalkKernel> pinUMXVertexNormalWalkKernel;
        private static UMXParallelKernelJob<UMXMeshCacheBurst.UMXSkinningKernel> pinUMXSkinningKernel;
        private static UMXParallelKernelJob<UMXMeshStreamBurst.UMXStream0BuildKernel> pinUMXStream0BuildKernel;
        private static UMXParallelKernelJob<UMXMeshStreamBurst.UMXStream0SkinnedBuildKernel> pinUMXStream0SkinnedBuildKernel;
        private static UMXParallelKernelJob<UMXMeshStreamBurst.UMXOverlayPositionSnapshotKernel> pinUMXOverlayPositionSnapshotKernel;
        private static UMXParallelKernelJob<UMXMeshStreamBurst.UMXExtraStreamBuildKernel> pinUMXExtraStreamBuildKernel;
        private static UMXParallelKernelJob<UMXMeshStreamBurst.UMXBoneWeightBuildKernel> pinUMXBoneWeightBuildKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXLoopPositionOverlayKernel> pinUMXLoopPositionOverlayKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXEdgeQuadOverlayKernel> pinUMXEdgeQuadOverlayKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXEdgeLineOverlayKernel> pinUMXEdgeLineOverlayKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXFaceLoopToVertexKernel> pinUMXFaceLoopToVertexKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXFaceAppearanceKernel> pinUMXFaceAppearanceKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXUVEdgePrevLoopKernel> pinUMXUVEdgePrevLoopKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXUVPointColorKernel> pinUMXUVPointColorKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXUVFaceColorKernel> pinUMXUVFaceColorKernel;
        private static UMXParallelKernelJob<UMXOverlayBurst.UMXUVEdgeAppearanceKernel> pinUMXUVEdgeAppearanceKernel;
        private static UMXParallelKernelJob<UMXOverlayIndexBurst.UMXFaceTriangleCountKernel> pinUMXFaceTriangleCountKernel;
        private static UMXParallelKernelJob<UMXOverlayIndexBurst.UMXFaceTriangleCountSumKernel> pinUMXFaceTriangleCountSumKernel;
        private static UMXParallelKernelJob<UMXOverlayIndexBurst.UMXFaceTriangleWriteKernel> pinUMXFaceTriangleWriteKernel;
        private static UMXParallelKernelJob<UMXOverlaySelectionBurst.UMXStridedColorScatterKernel> pinUMXStridedColorScatterKernel;
        private static UMXParallelKernelJob<UMXOverlaySelectionBurst.UMXStridedSoftColorScatterKernel> pinUMXStridedSoftColorScatterKernel;
        private static UMXParallelKernelJob<UMXOverlaySelectionBurst.UMXEdgeFlagColorKernel> pinUMXEdgeFlagColorKernel;
        private static UMXParallelKernelJob<UMXOverlaySelectionBurst.UMXEdgeSelectionScatterKernel> pinUMXEdgeSelectionScatterKernel;
        private static UMXParallelKernelJob<UMXOverlaySelectionBurst.UMXEdgeSoftSelectionKernel> pinUMXEdgeSoftSelectionKernel;
        private static UMXParallelKernelJob<UMXOverlaySelectionBurst.UMXFaceLoopColorKernel> pinUMXFaceLoopColorKernel;
        private static UMXParallelKernelJob<UMXOverlaySelectionBurst.UMXFaceLoopSoftSelectionKernel> pinUMXFaceLoopSoftSelectionKernel;
        private static UMXParallelKernelJob<UMXOverlaySelectionBurst.UMXProceduralEdgeBurst.UMXProceduralEdgeAppearanceKernel> pinUMXProceduralEdgeAppearanceKernel;
        private static UMXParallelKernelJob<UMXPatternFillBurst.UMXPatternFillKernel> pinUMXPatternFillKernel;
        private static UMXParallelKernelJob<UMXPreserveUVBurst.UMXUVScatterKernel> pinUMXUVScatterKernel;
        private static UMXParallelKernelJob<UMXPreserveUVBurst.UMXPreserveUVKernel> pinUMXPreserveUVKernel;
        private static UMXParallelKernelJob<UMXSelectionReduceBurst.UMXSelectionCenterSumKernel> pinUMXSelectionCenterSumKernel;
        private static UMXParallelKernelJob<UMXSelectionReduceBurst.UMXSelectionPositionAabbKernel> pinUMXSelectionPositionAabbKernel;
        private static UMXParallelKernelJob<UMXSelectionReduceBurst.UMXSelectionUVAabbKernel> pinUMXSelectionUVAabbKernel;
        private static UMXParallelKernelJob<UMXSelectionReduceBurst.UMXSelectionLoopUVAabbKernel> pinUMXSelectionLoopUVAabbKernel;
        private static UMXParallelKernelJob<UMXSnapBurst.UMXSnapProjectKernel> pinUMXSnapProjectKernel;
        private static UMXParallelKernelJob<UMXTangentBurst.UMXFaceTangentBuildKernel> pinUMXFaceTangentBuildKernel;
        private static UMXParallelKernelJob<UMXUVGridBurst.UMXUVFaceTriCountKernel> pinUMXUVFaceTriCountKernel;
        private static UMXParallelKernelJob<UMXUVGridBurst.UMXUVTriangleGatherKernel> pinUMXUVTriangleGatherKernel;
        private static UMXParallelKernelJob<UMXUVGridBurst.UMXUVBoundsReduceKernel> pinUMXUVBoundsReduceKernel;
        private static UMXParallelKernelJob<UMXUVGridBurst.UMXUVGridCountKernel> pinUMXUVGridCountKernel;
        private static UMXParallelKernelJob<UMXUVGridBurst.UMXUVGridScatterKernel> pinUMXUVGridScatterKernel;
        private static UMXParallelKernelJob<UMXUVGridBurst.UMXUVGridRectQueryKernel> pinUMXUVGridRectQueryKernel;
        private static UMXParallelKernelJob<UMXUVGridBurst.UMXUVMarkCountKernel> pinUMXUVMarkCountKernel;
        private static UMXParallelKernelJob<UMXUVGridBurst.UMXUVMarkScatterKernel> pinUMXUVMarkScatterKernel;
        private static UMXParallelKernelJob<UMXVertexTransformBurst.UMXVertexScatterTransformKernel> pinUMXVertexScatterTransformKernel;
        private static UMXSingleKernelJob<UMXBrushBurst.UMXVertexScaledNormalKernel> pinUMXVertexScaledNormalKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhCentroidBoundsKernel> pinUMXBvhCentroidBoundsKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhRadixSortKernel> pinUMXBvhRadixSortKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhClearCountersKernel> pinUMXBvhClearCountersKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhFrustumCandidatesKernel> pinUMXBvhFrustumCandidatesKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhVertexCandidatesKernel> pinUMXBvhVertexCandidatesKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhEdgeCandidatesKernel> pinUMXBvhEdgeCandidatesKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhRayPickFaceKernel> pinUMXBvhRayPickFaceKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhNodeAreaSumKernel> pinUMXBvhNodeAreaSumKernel;
        private static UMXSingleKernelJob<UMXBvhPickingBurst.UMXBvhRadixPrefixKernel> pinUMXBvhRadixPrefixKernel;
        private static UMXSingleKernelJob<UMXElementHintBurst.UMXHintMarkKernel> pinUMXHintMarkKernel;
        private static UMXSingleKernelJob<UMXElementHintBurst.UMXStateCollectKernel> pinUMXStateCollectKernel;
        private static UMXSingleKernelJob<UMXElementHintBurst.UMXStateSeenMaskKernel> pinUMXStateSeenMaskKernel;
        private static UMXSingleKernelJob<UMXElementHintBurst.UMXFlagAnySetKernel> pinUMXFlagAnySetKernel;
        private static UMXSingleKernelJob<UMXElementHintBurst.UMXLoopHintMarkKernel> pinUMXLoopHintMarkKernel;
        private static UMXSingleKernelJob<UMXFaceBatchCreateBurst.UMXRunOffsetCompactKernel> pinUMXRunOffsetCompactKernel;
        private static UMXSingleKernelJob<UMXFaceMaterialBurst.UMXFaceMaterialTriangleCountKernel> pinUMXFaceMaterialTriangleCountKernel;
        private static UMXSingleKernelJob<UMXFaceMaterialBurst.UMXFaceMaterialIndexPackKernel> pinUMXFaceMaterialIndexPackKernel;
        private static UMXSingleKernelJob<UMXIslandBurst.UMXUVIslandCollectKernel> pinUMXUVIslandCollectKernel;
        private static UMXSingleKernelJob<UMXIslandBurst.UMXIsolateCollectKernel> pinUMXIsolateCollectKernel;
        private static UMXSingleKernelJob<UMXMeshCacheBurst.UMXFacePlaneSingleKernel> pinUMXFacePlaneSingleKernel;
        private static UMXSingleKernelJob<UMXMeshCacheBurst.UMXVertexBoundsKernel> pinUMXVertexBoundsKernel;
        private static UMXSingleKernelJob<UMXMeshCacheBurst.UMXAnimatedBoundsKernel> pinUMXAnimatedBoundsKernel;
        private static UMXSingleKernelJob<UMXMeshStreamBurst.UMXBurstProbeKernel> pinUMXBurstProbeKernel;
        private static UMXSingleKernelJob<UMXMeshValidateBurst.UMXMeshValidateKernel> pinUMXMeshValidateKernel;
        private static UMXSingleKernelJob<UMXOverlayIndexBurst.UMXQuadIndexKernel> pinUMXQuadIndexKernel;
        private static UMXSingleKernelJob<UMXOverlayIndexBurst.UMXEdgeQuadIndexKernel> pinUMXEdgeQuadIndexKernel;
        private static UMXSingleKernelJob<UMXOverlayIndexBurst.UMXEdgeLineIndexKernel> pinUMXEdgeLineIndexKernel;
        private static UMXSingleKernelJob<UMXOverlayIndexBurst.UMXPointIndexKernel> pinUMXPointIndexKernel;
        private static UMXSingleKernelJob<UMXOverlayIndexBurst.UMXManagedFaceCollectKernel> pinUMXManagedFaceCollectKernel;
        private static UMXSingleKernelJob<UMXOverlayIndexBurst.UMXFaceTriangleOffsetKernel> pinUMXFaceTriangleOffsetKernel;
        private static UMXSingleKernelJob<UMXSnapBurst.UMXSnapVertexCandidateKernel> pinUMXSnapVertexCandidateKernel;
        private static UMXSingleKernelJob<UMXSnapBurst.UMXSnapEdgeCenterCandidateKernel> pinUMXSnapEdgeCenterCandidateKernel;
        private static UMXSingleKernelJob<UMXSnapBurst.UMXSnapFaceCenterCandidateKernel> pinUMXSnapFaceCenterCandidateKernel;
        private static UMXSingleKernelJob<UMXTransformInitBurst.UMXVertexIncidentFaceCountKernel> pinUMXVertexIncidentFaceCountKernel;
        private static UMXSingleKernelJob<UMXTransformInitBurst.UMXFaceNormalSumKernel> pinUMXFaceNormalSumKernel;
        private static UMXSingleKernelJob<UMXTransformInitBurst.UMXVertexFaceNormalSumKernel> pinUMXVertexFaceNormalSumKernel;
        private static UMXSingleKernelJob<UMXTransformInitBurst.UMXEdgeFaceNormalSumKernel> pinUMXEdgeFaceNormalSumKernel;
        private static UMXSingleKernelJob<UMXTransformInitBurst.UMXFaceLoopCollectKernel> pinUMXFaceLoopCollectKernel;
        private static UMXSingleKernelJob<UMXUVGridBurst.UMXUVPrefixSumKernel> pinUMXUVPrefixSumKernel;
#pragma warning restore 0169
    }
}
