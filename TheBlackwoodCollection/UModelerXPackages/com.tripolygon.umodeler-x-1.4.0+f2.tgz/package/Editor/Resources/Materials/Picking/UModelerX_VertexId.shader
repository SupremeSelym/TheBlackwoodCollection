﻿Shader "Hidden/UModelerX/VertexId"
{
    Properties
    {
        _VertexSize("VertexSize", float) = 2.5
		[Enum(UnityEngine.Rendering.CullMode)] _CullMode("CullMode", Float) = 0
	}
    SubShader
    {
        Tags 
        { 
            "RenderType" = "Opaque"  
            "LightMode" = "Always" 
            "UModelerXPicker" = "VertexID" 
        }

        LOD 100

        Blend One OneMinusSrcAlpha
        Lighting Off
        ZWrite On
        ZTest On

        Cull Off
        Offset -1, -1

        Pass 
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            /// 버텍스 풀링 변형이 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
            #pragma target 4.5
            #pragma multi_compile_local _ UMX_OVERLAY_PULL
            #include "UnityCG.cginc"
            #include "../Overlay/UModelerX.cginc"

            float _VertexSize;
            float3 _CameraPos;

            struct appdata
            {
                float4 vertex : POSITION;
                fixed4 color : COLOR;
                float2 vertexRect : TEXCOORD0;
			};

            struct v2f
            {
                float4 pos : SV_POSITION;
                fixed4 color : COLOR;
            };

#if defined(UMX_OVERLAY_PULL)
            StructuredBuffer<float3> _UMXOverlayPosition;
            StructuredBuffer<uint> _UMXOverlayColor;
            StructuredBuffer<float2> _UMXOverlayUV0;

            appdata UMXFetchVertex(uint vid)
            {
                appdata v;
                v.vertex = float4(_UMXOverlayPosition[vid], 1.0);
                v.color = UMXUnpackColor32(_UMXOverlayColor[vid]);
                v.vertexRect = _UMXOverlayUV0[vid];
                return v;
            }
#endif

            v2f vertCore(appdata v)
            {
                v2f o;

                float4 p = UMXOverlayToClipPos(v.vertex);
                p.z += p.w * _VertexSize * 0.00002 ;
                o.color = v.color;
    
                float2 pixelOffset = float2(_VertexSize / _ScreenParams.x, _VertexSize / _ScreenParams.y) * p.w * v.vertexRect;
                o.pos = p + float4(pixelOffset.x, pixelOffset.y, 0, 0);

                return o;
            }

#if defined(UMX_OVERLAY_PULL)
            v2f vert(uint drawIndex : SV_VertexID) { return vertCore(UMXFetchVertex(UMXOverlayIndex(drawIndex))); }
#else
            v2f vert(appdata v) { return vertCore(v); }
#endif

            fixed4 frag(v2f i) : SV_Target
            {
                return i.color;
            }
            ENDCG
        }
	}
}
