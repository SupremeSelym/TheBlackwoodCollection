﻿Shader "Hidden/UModelerX/DrawUVEdgePainting"
{
    Properties
    {
		[Enum(UnityEngine.Rendering.CompareFunction)] _ZTest("ZTest", Float) = 0
		[Enum(UnityEngine.Rendering.CullMode)] _CullMode("CullMode", Float) = 0
        _ClipPlane("Clip Plane", Vector) = (0, 0.5, 0, 0)
	}
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Blend SrcAlpha OneMinusSrcAlpha
        Lighting Off
        ZWrite On
        ZTest Always

        Cull Off
        Offset -1, -1

        Pass 
        {
	        Name "UVEdgeGeometry"

            CGPROGRAM
            /// 버텍스 풀링 변형이 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_local _ UMX_OVERLAY_PULL
            #include "UnityCG.cginc"
            #include "UModelerX.cginc"

            float4 _OrthoParams;
            float4 _EdgeWireframeColor;
            float _EdgeThickness;
            float4 _ClipPlane;

            struct appdata
			{
				float2 uvPos : TEXCOORD0;
				float3 uvNextPos : TEXCOORD2;
			};

            struct v2f
            {
                float4 pos : SV_POSITION;
            };

#if defined(UMX_OVERLAY_PULL)
            StructuredBuffer<float2> _UMXOverlayUV0;
            StructuredBuffer<float3> _UMXOverlayUV2;

            appdata UMXFetchVertex(uint vid)
            {
                appdata v;
                v.uvPos = _UMXOverlayUV0[vid];
                v.uvNextPos = _UMXOverlayUV2[vid];
                return v;
            }
#endif

			v2f vertCore (appdata v)
			{
                v2f o;

                float4 p0 = UMXOverlayToClipPos(float4(v.uvPos, 0, 1));
                float4 p1 = UMXOverlayToClipPos(float4(v.uvNextPos.xy, 0, 1));
                float2 direction = normalize(p1 - p0) * _EdgeThickness;
                float4 offset = float4(-direction.y / _OrthoParams.x, direction.x / _OrthoParams.y, 0, 0);

                o.pos = p0 + offset * v.uvNextPos.z;

                return o;
			}

#if defined(UMX_OVERLAY_PULL)
            v2f vert(uint drawIndex : SV_VertexID) { return vertCore(UMXFetchVertex(UMXOverlayIndex(drawIndex))); }
#else
            v2f vert(appdata v) { return vertCore(v); }
#endif

            float4 frag(v2f i) : SV_Target
            {
                if (i.pos.y < _ClipPlane.y) {
                    return float4(0, 0, 0, 0);
                }
                else
                {
                    return _EdgeWireframeColor;
                }
			}
			ENDCG
        }
	}
    FallBack "Diffuse"
}
