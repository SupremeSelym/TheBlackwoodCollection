﻿Shader "Hidden/UModelerX/DrawUVEdgeProcedural"
{
    SubShader
    {
        Tags
        {
            "RenderType" = "Opaque"
            "LightMode" = "Always"
        }
        LOD 100

        Blend SrcAlpha OneMinusSrcAlpha
        Lighting Off
        ZWrite On
        ZTest GEqual

        Cull Off
        Offset -1, -1

        Pass
        {
            Name "UVEdgeProcedural"

            CGPROGRAM
            /// 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            #include "UModelerX.cginc"

            /// 선분 하나 = 화면 정렬 사각형(정점 6개). CPU 는 사각형을 만들지 않습니다.
            /// 슬롯 = 루프 ID 이고, 선분은 그 루프의 UV 에서 링 이전 루프의 UV 까지입니다
            /// (기존 경로가 인덱스로 (loopID, prevLoopID + 루프수) 쌍을 만든 것과 같습니다).
            StructuredBuffer<float2> _UMXUVEdgeUVs;
            /// 링 이전 루프 ID — 토폴로지 수명. UV 가 움직여도 다시 올리지 않습니다.
            StructuredBuffer<uint> _UMXUVEdgeTopology;
            /// x = 색(RGBA32), y = 하위16 두께(8.8 고정소수 픽셀) | 상위16 Z오프셋(UNorm16).
            StructuredBuffer<uint2> _UMXUVEdgeAppearance;

            float4 _OrthoParams;

            struct UMXUVEdgeVaryings
            {
                float4 pos : SV_POSITION;
                float4 color : COLOR;
            };

            UMXUVEdgeVaryings vert(uint vertexID : SV_VertexID)
            {
                uint loopIndex = vertexID / 6;
                uint corner = vertexID - loopIndex * 6;

                uint2 appearance = _UMXUVEdgeAppearance[loopIndex];
                float4 color = UMXUnpackColor32(appearance.x);
                float thickness = (appearance.y & 0xFFFF) * (1.0 / 256.0);
                float zOffset = (appearance.y >> 16) * (1.0 / 65535.0);

                uint prevLoopIndex = _UMXUVEdgeTopology[loopIndex];

                /// UVToPos 가 UV 를 클립 좌표로 옮깁니다(w = 1, z = 0.5).
                float4 p0 = UVToPos(_UMXUVEdgeUVs[loopIndex]);
                float4 p1 = UVToPos(_UMXUVEdgeUVs[prevLoopIndex]);
                p0.z -= zOffset;
                p1.z -= zOffset;

                UMXUVEdgeVaryings output;
                output.color = color;

                /// 두께 계산은 기존 지오메트리 경로와 같습니다 — 방향을 NDC 에서 정규화하고
                /// 수직 방향으로 두께/뷰포트 만큼 밀어 사각형을 만듭니다(가로세로비 보정 없음).
                float2 delta = p1.xy - p0.xy;
                float lengthSquared = dot(delta, delta);
                /// 길이가 0 이면 정규화가 정의되지 않습니다. 방향을 고정해 사각형이 사라지지 않게 합니다.
                float2 direction = (lengthSquared > 1e-12 ? delta * rsqrt(lengthSquared) : float2(1.0, 0.0))
                    * thickness;
                float2 offset = float2(-direction.y / _OrthoParams.x, direction.x / _OrthoParams.y);

                bool isP1 = (corner == 2) || (corner == 3) || (corner == 5);
                float side = ((corner == 1) || (corner == 4) || (corner == 5)) ? 1.0 : -1.0;

                float4 basePos = isP1 ? p1 : p0;
                float4 expanded = basePos;
                expanded.xy += offset * side;

                /// 알파 0 이면 여섯 정점을 한 점으로 모아 면적을 0 으로 만듭니다.
                output.pos = (color.a <= 0.0) ? p0 : expanded;
                return output;
            }

            float4 frag(UMXUVEdgeVaryings input) : SV_Target
            {
                return input.color;
            }
            ENDCG
        }
    }
}
