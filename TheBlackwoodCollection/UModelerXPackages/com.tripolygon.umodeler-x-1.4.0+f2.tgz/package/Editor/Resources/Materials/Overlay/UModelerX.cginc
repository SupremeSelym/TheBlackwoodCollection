﻿// 리깅 웨이트 오버레이 컬러 모드. 0 = Low/High 그라데이션, 1 = 무지개 colormap (기본)
float _UMXWeightColorMode;
float4 _UMXWeightLowColor;
float4 _UMXWeightHighColor;

float4 Temperature(float4 color, float weight)
{
    float softSelect = step(-0.01f, weight);

    // 무지개 colormap (mode 1)
    // 0 1,0,0 -> 0.5,0.5,0 -> 0, 1, 0 -> 0, 0.5, 0.5 -> 0,0,1
    float t = (1 - weight) * 2;
    float4 rainbow = float4(saturate(float3(1.5f - t, 1.0f - abs(t - 1), 1.5f - abs(t - 2))), color.w);

    // Low/High 그라데이션 (mode 0). authored RGBA 그대로 보간
    float4 gradient = lerp(_UMXWeightLowColor, _UMXWeightHighColor, saturate(weight));

    // _UMXWeightColorMode 는 0 또는 1 만 들어오므로 분기 없이 선택
    float4 selected = lerp(gradient, rainbow, _UMXWeightColorMode);
    return color * (1 - softSelect) + softSelect * selected;
}

// ── 오버레이 버텍스 풀링 ────────────────────────────────────────────────
// UMXOverlayMesh 가 채널별 GraphicsBuffer 를 바인드하면 정점 선언 없이 SV_VertexID 로 읽습니다.
// 오브젝트 행렬은 C# 이 GL 모델뷰에 실어 보내므로 여기서는 VP 만 곱합니다.
// 키워드가 꺼져 있으면(폴백 = Mesh + DrawMeshNow) 기존 계산 그대로입니다.

#if defined(UMX_OVERLAY_PULL)
// 인덱스도 우리가 든 버퍼에서 직접 읽습니다. 그리기는 인덱스 없는 프로시저럴 드로우이고,
// SV_VertexID 는 0..indexCount-1 의 일련번호로만 쓰므로 API 가 인덱스를 어떻게 넘기는지에 기대지 않습니다.
StructuredBuffer<uint> _UMXOverlayIndices;

uint UMXOverlayIndex(uint drawIndex)
{
    return _UMXOverlayIndices[drawIndex];
}
#endif

float4 UMXOverlayToClipPos(float4 objectPos)
{
#if defined(UMX_OVERLAY_PULL)
    // 즉시 모드(SetPass + DrawProceduralNow)에서는 UNITY_MATRIX_VP 가 현재 GL 모델뷰를 포함한다.
    // 오브젝트 행렬은 C# 이 GL.modelview 대입으로 거기 실어 보내므로
    // (GL.MultMatrix 는 월드 행렬만 바꿔 VP 에 들어가지 않는다)
    // 여기서 유니폼 행렬을 또 곱하면 이중 변환이 된다.
    return mul(UNITY_MATRIX_VP, objectPos);
#else
    return UnityObjectToClipPos(objectPos);
#endif
}

// Color32 채널(UNorm8 x4)을 정점 선언 없이 읽었을 때의 언팩. 바이트 0 이 R 입니다.
// 피킹 ID 색상. Triangulator.EncodeRGBA 와 같은 배치여야 합니다(r=상위, g=중간, b=하위).
// 프로시저럴 오버레이는 ID 를 버퍼에 저장하지 않고 정점 ID 에서 계산합니다.
float4 UMXEncodeElemID(uint id)
{
    return float4((id >> 16) & 0xFF, (id >> 8) & 0xFF, id & 0xFF, 255.0) * (1.0 / 255.0);
}

float4 UMXUnpackColor32(uint packed)
{
    return float4(packed & 0xFF, (packed >> 8) & 0xFF, (packed >> 16) & 0xFF, (packed >> 24) & 0xFF)
        * (1.0 / 255.0);
}

float4 UVToPos(float2 uvPos)
{
    float4 worldPos = float4(uvPos, 1, 1);
    worldPos = mul(UNITY_MATRIX_VP, worldPos);
    return float4(worldPos.xy, 0.5, 1);
}

