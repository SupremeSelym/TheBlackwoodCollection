﻿Shader "Hidden/UModelerX/DrawUVVertexProcedural"
{
    Properties
    {
        _VertexSize("VertexSize", float) = 0.5
    }
    SubShader
    {
        Tags
        {
            "RenderType" = "Opaque"
            "LightMode" = "Always"
        }
        LOD 100

        Blend One OneMinusSrcAlpha
        Lighting Off
        ZWrite Off
        ZTest Always

        Cull Off
        Offset -1,-1

        Pass
        {
            Name "UVVertexRectProcedural"

            CGPROGRAM
            /// 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            #include "UModelerX.cginc"

            /// 루프 하나 = 화면 정렬 사각형(정점 6개). CPU 는 사각형을 만들지 않습니다.
            /// 슬롯 = 루프 ID 라 인덱스 버퍼도 토폴로지 버퍼도 필요 없습니다 —
            /// 루프당 데이터는 색 하나(4바이트)뿐이고 UV 는 다른 UV 오버레이와 공유합니다.
            StructuredBuffer<float2> _UMXUVPointUVs;
            /// RGBA32. 알파 0 은 "그리지 않음"(죽었거나 필터에서 빠진 루프)입니다.
            StructuredBuffer<uint> _UMXUVPointColors;

            float _VertexSize;
            float4 _OrthoParams;

            struct UMXUVPointVaryings
            {
                float4 pos : SV_POSITION;
                float4 color : COLOR;
            };

            UMXUVPointVaryings vert(uint vertexID : SV_VertexID)
            {
                uint loopIndex = vertexID / 6;
                uint corner = vertexID - loopIndex * 6;

                float4 color = UMXUnpackColor32(_UMXUVPointColors[loopIndex]);
                /// UVToPos 가 UV 를 클립 좌표로 옮깁니다(w = 1, z = 0.5).
                /// 오브젝트 행렬은 호출측이 GL 에 실어 보내므로 여기서는 그 함수만 씁니다.
                float4 p = UVToPos(_UMXUVPointUVs[loopIndex]);

                UMXUVPointVaryings output;
                output.color = color;

                /// 크기 규약은 기존 경로와 같습니다 — 한쪽 반경이 _VertexSize 픽셀.
                float2 pixelOffset = float2(_VertexSize * 2.0 / _OrthoParams.x,
                                            _VertexSize * 2.0 / _OrthoParams.y);

                /// 사각형 여섯 정점: (-,-) (+,-) (-,+) / (-,+) (+,-) (+,+)
                float cornerX = ((corner == 1) || (corner == 4) || (corner == 5)) ? 1.0 : -1.0;
                float cornerY = ((corner == 2) || (corner == 3) || (corner == 5)) ? 1.0 : -1.0;

                float4 expanded = p;
                expanded.xy += float2(cornerX, cornerY) * pixelOffset;

                /// 알파 0 이면 여섯 정점을 한 점으로 모아 면적을 0 으로 만듭니다.
                /// 알파만 0 으로 두면 픽셀은 그대로 래스터되므로 채우기 비용이 남습니다.
                output.pos = (color.a <= 0.0) ? p : expanded;
                return output;
            }

            float4 frag(UMXUVPointVaryings input) : SV_Target
            {
                return input.color;
            }
            ENDCG
        }
    }
}
