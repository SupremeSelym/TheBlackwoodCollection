﻿Shader "Hidden/UModelerX/DrawFaceProcedural"
{
    Properties
    {
        [Enum(UnityEngine.Rendering.CompareFunction)] _ZTest("ZTest", Float) = 0
        [Enum(UnityEngine.Rendering.CullMode)] _CullMode("CullMode", Float) = 2
        [Enum(Off, 0, On, 1)] _ZWrite("ZWrite", Float) = 1
    }
    SubShader
    {
        Tags
        {
            "RenderType" = "Opaque"
            "LightMode" = "Always"
            "UModelerXPicker" = "FaceID"
        }
        LOD 100

        Lighting Off
        Offset -1, -1

        CGINCLUDE
        #include "UnityCG.cginc"
        #include "UModelerX.cginc"

        /// 삼각형 하나 = 정점 3개. CPU 는 좌표를 루프마다 펼치지 않고,
        /// 좌표는 정점 인덱스로 공유 버퍼에서 당겨옵니다(엣지·버텍스 오버레이와 같은 버퍼).
        ///
        /// 엣지와 달리 정점 ID 에서 면 ID 를 유도할 수 없습니다 — 삼각형 수가 면마다 다르기
        /// 때문입니다. 그래서 토폴로지가 루프 인덱스를 직접 담고, 루프별 데이터를 그 인덱스로
        /// 찾습니다. 피킹 ID 도 계산하지 않고 버퍼 값을 그대로 씁니다(기존 경로가 이미
        /// 루프별로 인코딩해 두므로 그쪽과 인코딩이 어긋날 여지를 없앱니다).
        StructuredBuffer<float3> _UMXFacePositions;
        /// 삼각형 코너의 루프 인덱스. 삼각화 수명.
        StructuredBuffer<uint3> _UMXFaceTopology;
        /// 루프 → 정점 인덱스. 토폴로지 수명.
        StructuredBuffer<uint> _UMXFaceLoopToVertex;
        /// 루프별 표시 색. 선택·하이라이트 수명.
        StructuredBuffer<float4> _UMXFaceColor;
        /// 루프별 소프트셀렉션 값. -1 이면 색을 그대로 씁니다(Temperature 규약).
        StructuredBuffer<float> _UMXFaceSoft;
        /// 루프별 피킹 ID 색(Color32 팩).
        StructuredBuffer<uint> _UMXFacePickID;

        struct UMXFaceVaryings
        {
            float4 pos : SV_POSITION;
            float4 color : COLOR;
            float softSelection : TEXCOORD0;
            nointerpolation uint pickID : TEXCOORD1;
        };

        UMXFaceVaryings UMXFaceVert(uint vertexID)
        {
            UMXFaceVaryings output;

            uint triangleIndex = vertexID / 3;
            uint corner = vertexID - triangleIndex * 3;

            uint3 triangleLoops = _UMXFaceTopology[triangleIndex];
            /// 코너별 분기 대신 인덱싱으로 고릅니다(동적 인덱싱이 안 되는 곳이 있어 선택으로 풀어씁니다).
            uint loopIndex = corner == 0 ? triangleLoops.x : (corner == 1 ? triangleLoops.y : triangleLoops.z);

            uint vertexIndex = _UMXFaceLoopToVertex[loopIndex];

            /// 즉시 모드(SetPass + DrawProceduralNow)에서는 UNITY_MATRIX_VP 가 현재 GL 모델뷰를
            /// 포함합니다. 오브젝트 행렬은 호출측이 GL.modelview 대입으로 거기 실어 보내므로
            /// (GL.MultMatrix 는 월드 행렬만 바꿔 VP 에 안 들어감) VP 만 곱합니다 — UMXOverlayToClipPos 를 쓰면
            /// UMX_OVERLAY_PULL 미정의라 UnityObjectToClipPos(MVP) 로 가서 이중 변환이 됩니다.
            output.pos = mul(UNITY_MATRIX_VP, float4(_UMXFacePositions[vertexIndex], 1.0));
            output.color = _UMXFaceColor[loopIndex];
            output.softSelection = _UMXFaceSoft[loopIndex];
            output.pickID = _UMXFacePickID[loopIndex];
            return output;
        }
        ENDCG

        Pass
        {
            Name "FaceProcedural"

            /// 표시 상태는 DrawFace.shader 와 같습니다.
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite [_ZWrite]
            ZTest [_ZTest]
            Cull [_CullMode]

            CGPROGRAM
            /// 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag

            UMXFaceVaryings vert(uint vertexID : SV_VertexID) { return UMXFaceVert(vertexID); }

            float4 frag(UMXFaceVaryings input) : SV_Target
            {
                return Temperature(input.color, input.softSelection);
            }
            ENDCG
        }

        Pass
        {
            Name "FaceProceduralId"

            /// ID 는 섞으면 안 됩니다. 클리어(0) 위에 그대로 덮어씁니다.
            /// 상태는 UModelerX_FaceId.shader 와 같습니다.
            Blend Off
            ZWrite On
            ZTest LEqual
            Cull [_CullMode]

            CGPROGRAM
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag

            UMXFaceVaryings vert(uint vertexID : SV_VertexID) { return UMXFaceVert(vertexID); }

            float4 frag(UMXFaceVaryings input) : SV_Target
            {
                /// 기존 경로가 루프별로 인코딩해 둔 값을 그대로 돌려줍니다
                /// (숨김 면의 0 처리까지 그쪽 규칙을 따릅니다).
                return UMXUnpackColor32(input.pickID);
            }
            ENDCG
        }
    }
}
