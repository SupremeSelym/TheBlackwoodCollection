﻿Shader "Hidden/UModelerX/DrawUVFace"
{
    Properties
    {
		[Enum(UnityEngine.Rendering.CompareFunction)] _ZTest("ZTest", Float) = 0
		[Enum(UnityEngine.Rendering.CullMode)] _CullMode("CullMode", Float) = 0
		/// 겹침 상한용 스텐실 상태. C# 이 패스마다 갈아끼웁니다(EditorMeshesBase.SetupUVFace*Pass).
		/// 기본값은 "스텐실을 쓰지 않음" 입니다 — 상한이 꺼져 있으면 이 상태 그대로 그립니다.
		_UVFaceStencilRef("Stencil Ref", Float) = 255
		_UVFaceStencilComp("Stencil Comp", Float) = 8
		_UVFaceStencilOp("Stencil Op", Float) = 0
		/// 1 이면 선택·하이라이트 페이스만 그립니다(우선 패스).
		_UVFacePriorityOnly("Priority Only", Float) = 0
		_UVFacePrioritySelected("Priority Selected Color", Color) = (0,0,0,0)
		_UVFacePriorityHighlight("Priority Highlight Color", Color) = (0,0,0,0)
	}
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Blend SrcAlpha OneMinusSrcAlpha
        Lighting Off
        ZWrite Off
        ZTest Always

        Cull Off
        Offset -1, -1

        /// 픽셀당 겹침 상한을 스텐실로 셉니다. 상태는 C# 이 패스마다 지정합니다.
        ///  - 우선 패스(선택·하이라이트): Always / Replace / Ref 255 — 상한 없이 그리고 픽셀을 점유.
        ///  - 일반 패스: Greater / IncrSat / Ref N — 스텐실값이 N 보다 적을 때만 통과하고 1 올립니다.
        ///    우선 패스가 255 로 점유한 픽셀은 N > 255 가 거짓이라 통과하지 못합니다.
        ///  - 상한이 꺼져 있으면 Always / Keep 이라 스텐실이 아무 일도 하지 않습니다.
        Stencil
        {
            Ref [_UVFaceStencilRef]
            Comp [_UVFaceStencilComp]
            Pass [_UVFaceStencilOp]
        }

        Pass
        {
            Name "Face"

			CGPROGRAM
			#pragma vertex vert
			#pragma fragment frag
			/// 버텍스 풀링 변형이 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
			#pragma target 4.5
			#pragma multi_compile_local _ UMX_OVERLAY_PULL
			#include "UnityCG.cginc"
            #include "UModelerX.cginc"

			struct appdata
			{
				float2 uvPos : TEXCOORD0;
                fixed4 color : COLOR;
			};

            struct v2f
            {
                float4 pos : SV_POSITION;
                float4 color : COLOR;
            };

            float _UVFacePriorityOnly;
            float4 _UVFacePrioritySelected;
            float4 _UVFacePriorityHighlight;

            /// 선택·하이라이트 색인가. 색은 Color32 로 양자화되어 들어오고 C# 도 같은 양자화를
            /// 거쳐 넘기므로, 서로 다른 색은 최소 1/255(≈0.0039) 만큼 떨어져 이 허용치로 갈립니다.
            /// 한 페이스의 세 코너가 같은 색이라 보간해도 값이 그대로여서 프래그먼트에서 판정합니다.
            bool UMXUVFaceIsPriority(float4 color)
            {
                return all(abs(color - _UVFacePrioritySelected) < 0.001)
                    || all(abs(color - _UVFacePriorityHighlight) < 0.001);
            }

#if defined(UMX_OVERLAY_PULL)
            StructuredBuffer<float2> _UMXOverlayUV0;
            StructuredBuffer<uint>   _UMXOverlayColor;

            appdata UMXFetchVertex(uint vid)
            {
                appdata v;
                v.uvPos = _UMXOverlayUV0[vid];
                v.color = UMXUnpackColor32(_UMXOverlayColor[vid]);
                return v;
            }
#endif

			v2f vertCore (appdata v)
			{
				v2f o;

                o.pos = UVToPos(v.uvPos);
                o.color = v.color;
                return o;
			}

#if defined(UMX_OVERLAY_PULL)
            v2f vert(uint drawIndex : SV_VertexID) { return vertCore(UMXFetchVertex(UMXOverlayIndex(drawIndex))); }
#else
            v2f vert(appdata v) { return vertCore(v); }
#endif
			
            float4 frag(v2f i) : SV_Target
            {
                /// 알파 0 은 "그리지 않음" 규약입니다. 블렌드 결과는 어차피 같지만
                /// 버리지 않으면 겹침 카운트를 한 장 먹으므로 여기서 걷어냅니다.
                clip(i.color.a - 0.001);
                /// 우선 패스는 선택·하이라이트만 남깁니다. 일반 패스(_UVFacePriorityOnly = 0)는
                /// 우선 패스가 스텐실로 점유한 픽셀에서 이미 막히므로 여기서 거를 필요가 없습니다.
                clip(_UVFacePriorityOnly * (UMXUVFaceIsPriority(i.color) ? 1.0 : -1.0));
                return i.color;
			}
			ENDCG
        }
	}
}
