﻿Shader "Hidden/UModelerX/DrawFace"
{
    Properties
    {
		[Enum(UnityEngine.Rendering.CompareFunction)] _ZTest("ZTest", Float) = 0
		[Enum(UnityEngine.Rendering.CullMode)] _CullMode("CullMode", Float) = 0
		[Enum(Off, 0, On, 1)] _ZWrite("ZWrite", Float) = 1
	}
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Blend SrcAlpha OneMinusSrcAlpha
        Lighting Off
        ZWrite [_ZWrite]
        ZTest[_ZTest]
        Offset -1, -1
        Cull[_CullMode]

        Pass
        {
            Name "Face"

			CGPROGRAM
			#pragma vertex vert
			#pragma fragment frag
			/// 버텍스 풀링 변형이 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
			#pragma target 4.5
			#pragma multi_compile_local _ UMX_OVERLAY_PULL
			#include "UnityCG.cginc"
			#include "UModelerX.cginc"

			struct appdata
			{
				float4 vertex : POSITION;
                float4 color : TEXCOORD2;
                // y는 softSelection. 0이면 color를 넣어줌.
                float2 edgeData : TEXCOORD0;
			};

            struct v2f
            {
                float4 pos : SV_POSITION;
                float4 color : COLOR;
                float softSelection : TEXCOORD0;
            };

#if defined(UMX_OVERLAY_PULL)
            StructuredBuffer<float3> _UMXOverlayPosition;
            StructuredBuffer<float2> _UMXOverlayUV0;
            StructuredBuffer<float4> _UMXOverlayUV2;

            appdata UMXFetchVertex(uint vid)
            {
                appdata v;
                v.vertex = float4(_UMXOverlayPosition[vid], 1.0);
                v.edgeData = _UMXOverlayUV0[vid];
                v.color = _UMXOverlayUV2[vid];
                return v;
            }
#endif

			v2f vertCore (appdata v)
			{
				v2f o;
                o.pos = UMXOverlayToClipPos(v.vertex);
                o.color = v.color;
                o.softSelection = v.edgeData.y;
                return o;
			}

#if defined(UMX_OVERLAY_PULL)
            v2f vert(uint drawIndex : SV_VertexID) { return vertCore(UMXFetchVertex(UMXOverlayIndex(drawIndex))); }
#else
            v2f vert(appdata v) { return vertCore(v); }
#endif
			
            float4 frag(v2f i) : SV_Target
            {
                // return float4(i.color.xyz, 1);
                return Temperature(i.color, i.softSelection);
			}
			ENDCG
        }
	}
}
