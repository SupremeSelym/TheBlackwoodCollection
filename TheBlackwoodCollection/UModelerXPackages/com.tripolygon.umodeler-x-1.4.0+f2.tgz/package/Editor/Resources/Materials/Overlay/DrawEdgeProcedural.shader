﻿Shader "Hidden/UModelerX/DrawEdgeProcedural"
{
    Properties
    {
        [Enum(UnityEngine.Rendering.CompareFunction)] _ZTest("ZTest", Float) = 0
        _ZOffset("ZOffset", Float) = 0.00003
        _UMXEdgeMinWidth("Min Width (px)", Float) = 1.0
    }
    SubShader
    {
        Tags
        {
            "RenderType" = "Opaque"
            "LightMode" = "Always"
            "UModelerXPicker" = "EdgeID"
        }
        LOD 100

        Lighting Off
        // 화면 정렬 사각형이라 어느 면이 앞인지 의미가 없습니다.
        Cull Off
        Offset -1, -1

        CGINCLUDE
        #include "UnityCG.cginc"
        #include "UModelerX.cginc"

        /// 엣지 하나 = 화면 공간 사각형(정점 6개). CPU 는 사각형을 만들지 않고
        /// 좌표는 정점 인덱스로 공유 버퍼에서 당겨옵니다.
        /// 지오메트리 셰이더를 쓰지 않으므로 Metal 에서도 같은 경로가 돕니다.
        ///
        /// 버퍼를 셋으로 묶은 이유: 버텍스 단계 버퍼 입력 한도가 플랫폼마다 다르고
        /// (UMXOverlayMesh 가 maxComputeBufferInputsVertex >= 4 로 게이트합니다)
        /// 좌표·토폴로지·외형은 수명이 달라 이 셋이 자연스러운 경계입니다.
        StructuredBuffer<float3> _UMXEdgePositions;
        /// (vertexA, vertexB) — 토폴로지 수명. 정점이 움직여도 다시 올리지 않습니다.
        StructuredBuffer<uint2> _UMXEdgeTopology;
        /// x = colorA(RGBA32), y = colorB(RGBA32),
        /// z = 하위16 폭(8.8 고정소수 픽셀) | 상위16 플래그,
        /// w = 하위16 softA | 상위16 softB (둘 다 [-1,1] 을 UNorm16 으로 담음).
        StructuredBuffer<uint4> _UMXEdgeAppearance;

        float _ZOffset;
        float _UMXEdgeMinWidth;

        /// 니어 평면 판정에 쓰는 최소 w. 클립 공간 w 는 카메라 앞쪽 거리라 이 값 아래면 뒤에 있습니다.
        static const float UMXEdgeNearW = 1e-4;

        struct UMXEdgeVaryings
        {
            float4 pos : SV_POSITION;
            float4 color : COLOR;
            /// x = softSelection(-1 이면 색 그대로), y = 폭 클램프 보정(알파 스케일).
            float2 shading : TEXCOORD0;
            nointerpolation uint edgeID : TEXCOORD1;
        };

        /// [-1,1] 을 담은 UNorm16 을 되돌립니다.
        float UMXUnpackSigned16(uint packed)
        {
            return (packed & 0xFFFF) * (2.0 / 65535.0) - 1.0;
        }

        UMXEdgeVaryings UMXEdgeVert(uint vertexID)
        {
            uint edgeID = vertexID / 6;
            uint corner = vertexID - edgeID * 6;

            uint2 topology = _UMXEdgeTopology[edgeID];
            /// 오브젝트 행렬은 C# 이 GL 모델뷰에 실어 보내므로 여기서는 VP 만 곱합니다
            /// (GL.modelview 대입으로 싣습니다 — GL.MultMatrix 는 월드 행렬만 바꿔 VP 에 안 들어갑니다).
            float4 clipA = mul(UNITY_MATRIX_VP, float4(_UMXEdgePositions[topology.x], 1.0));
            float4 clipB = mul(UNITY_MATRIX_VP, float4(_UMXEdgePositions[topology.y], 1.0));

            uint4 appearance = _UMXEdgeAppearance[edgeID];
            float4 colorA = UMXUnpackColor32(appearance.x);
            float4 colorB = UMXUnpackColor32(appearance.y);
            float2 soft = float2(UMXUnpackSigned16(appearance.w), UMXUnpackSigned16(appearance.w >> 16));
            /// 폭은 사각형의 전체 픽셀 폭입니다(기존 edgeData.x 와 같은 규약).
            float widthPixels = (appearance.z & 0xFFFF) * (1.0 / 256.0);

            /// 니어 평면 클리핑. 한쪽 끝점이 카메라 뒤에 있는데 그대로 나누면
            /// 화면 전체를 덮는 사각형이 나옵니다. 클립 공간 직선 보간은 원근 보정과 일치하므로
            /// 여기서 잘라도 됩니다 — 색과 소프트셀렉션도 **같은 t 로** 옮겨야 그라데이션이 안 튑니다.
            bool behindA = clipA.w < UMXEdgeNearW;
            bool behindB = clipB.w < UMXEdgeNearW;
            bool bothBehind = behindA && behindB;
            if (behindA && bothBehind == false)
            {
                float t = (UMXEdgeNearW - clipA.w) / (clipB.w - clipA.w);
                clipA = lerp(clipA, clipB, t);
                colorA = lerp(colorA, colorB, t);
                soft.x = lerp(soft.x, soft.y, t);
            }
            else if (behindB && bothBehind == false)
            {
                float t = (UMXEdgeNearW - clipB.w) / (clipA.w - clipB.w);
                clipB = lerp(clipB, clipA, t);
                colorB = lerp(colorB, colorA, t);
                soft.y = lerp(soft.y, soft.x, t);
            }

            /// 화면 방향. 평행이동은 방향 계산에서 상쇄되므로 NDC 중심 보정은 생략합니다.
            /// 렌더 텍스처 대상에서 투영 y 부호가 뒤집혀도 사각형이 대칭이라 결과는 같습니다.
            float2 pixelA = (clipA.xy / clipA.w) * (0.5 * _ScreenParams.xy);
            float2 pixelB = (clipB.xy / clipB.w) * (0.5 * _ScreenParams.xy);
            float2 delta = pixelB - pixelA;
            float lengthSquared = dot(delta, delta);
            /// 길이가 0 이면 정규화가 정의되지 않습니다. 방향을 고정해 사각형이 사라지지 않게 합니다.
            float2 direction = lengthSquared > 1e-8 ? delta * rsqrt(lengthSquared) : float2(1.0, 0.0);
            float2 perpendicular = float2(-direction.y, direction.x);

            /// 1픽셀 미만 폭은 래스터에서 깜빡이므로 폭을 최소값까지 올리고
            /// 줄어든 만큼 알파로 되돌립니다(프리멀티플라이드 블렌드라 결과 전체에 곱합니다).
            float clampedWidth = max(widthPixels, _UMXEdgeMinWidth);
            float fade = clampedWidth > 0.0 ? widthPixels / clampedWidth : 0.0;

            bool isB = (corner == 2) || (corner == 3) || (corner == 5);
            float side = ((corner == 1) || (corner == 4) || (corner == 5)) ? 1.0 : -1.0;

            float4 clipPos = isB ? clipB : clipA;

            UMXEdgeVaryings output;
            output.color = isB ? colorB : colorA;
            output.shading = float2(isB ? soft.y : soft.x, fade);
            output.edgeID = edgeID;

            float2 offsetPixels = perpendicular * (clampedWidth * 0.5) * side;
            clipPos.xy += offsetPixels * (2.0 / _ScreenParams.xy) * clipPos.w;
            clipPos.z += _ZOffset * clipPos.w;

            /// 양쪽 다 카메라 뒤면 여섯 정점을 한 점으로 모아 면적을 0 으로 만듭니다.
            output.pos = bothBehind ? clipA : clipPos;
            return output;
        }
        ENDCG

        Pass
        {
            Name "WireframeProcedural"

            Blend One OneMinusSrcAlpha
            ZWrite Off
            ZTest [_ZTest]

            CGPROGRAM
            /// 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag

            UMXEdgeVaryings vert(uint vertexID : SV_VertexID) { return UMXEdgeVert(vertexID); }

            float4 frag(UMXEdgeVaryings input) : SV_Target
            {
                return Temperature(input.color, input.shading.x) * input.shading.y;
            }
            ENDCG
        }

        Pass
        {
            Name "WireframeProceduralId"

            /// ID 는 섞으면 안 됩니다. 클리어(0) 위에 그대로 덮어씁니다.
            Blend Off
            ZWrite On
            ZTest LEqual

            CGPROGRAM
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag

            UMXEdgeVaryings vert(uint vertexID : SV_VertexID) { return UMXEdgeVert(vertexID); }

            float4 frag(UMXEdgeVaryings input) : SV_Target
            {
                /// 정점 ID 에서 엣지 ID 가 나오므로 피킹 ID 를 버퍼에 저장하지 않습니다.
                return UMXEncodeElemID(input.edgeID + 1);
            }
            ENDCG
        }
    }
}
