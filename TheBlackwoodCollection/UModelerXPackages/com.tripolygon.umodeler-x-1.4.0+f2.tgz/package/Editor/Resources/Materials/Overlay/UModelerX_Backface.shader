Shader "Unlit/UModelerX_Backface"
{
    Properties
    {
        _MainColor("Color", Color) = (0.42, 0.42, 0.42,1)
        _TransparentColor("TransparentColor", Color) = (0.21, 0.21, 0.21, 0.5)
        _Alpha ("Alpha", Float) = 1
        [Enum(UnityEngine.Rendering.CullMode)] _CullMode("CullMode", Float) = 1
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Pass
        {
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite On
            ZTest [_ZTest]
            Cull [_CullMode]

            Offset -1, -1

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            /// ���ؽ� Ǯ�� ������ ���ؽ� �ܰ迡�� StructuredBuffer �� �����Ƿ� 4.5 �� �ʿ��մϴ�.
            #pragma target 4.5
            #pragma multi_compile_local _ UMX_OVERLAY_PULL

            #include "UnityCG.cginc"
            #include "UModelerX.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float4 color : TEXCOORD2;
            };

            struct v2f
            {
                float4 vertex : SV_POSITION;
                float4 color : COLOR;
                // float soft
            };

            float4 _MainColor;
            float4 _TransparentColor;
            float _Alpha;

#if defined(UMX_OVERLAY_PULL)
            StructuredBuffer<float3> _UMXOverlayPosition;
            StructuredBuffer<float4> _UMXOverlayUV2;

            appdata UMXFetchVertex(uint vid)
            {
                appdata v;
                v.vertex = float4(_UMXOverlayPosition[vid], 1.0);
                v.color = _UMXOverlayUV2[vid];
                return v;
            }
#endif

            v2f vertCore (appdata v)
            {
                v2f o;
                o.vertex = UMXOverlayToClipPos(v.vertex);
                o.color = v.color;
                return o;
            }

#if defined(UMX_OVERLAY_PULL)
            v2f vert(uint drawIndex : SV_VertexID) { return vertCore(UMXFetchVertex(UMXOverlayIndex(drawIndex))); }
#else
            v2f vert(appdata v) { return vertCore(v); }
#endif

            fixed4 frag(v2f i) : SV_Target
            {
                // ���� �� ������ ���
                if (i.color.r > 0.8 && i.color.g < 0.0001 && i.color.b < 0.0001)
                    return i.color;
                // �ʷϻ� (���õ� ����� ���)
                if (i.color.r < 0.1 && i.color.g > 0.8 && i.color.b < 0.1)
                    return i.color;
                if (_Alpha == 0)
                    return _TransparentColor;
                return _MainColor;
            }
            ENDCG
        }
    }
}
