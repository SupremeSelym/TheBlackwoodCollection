Shader "Hidden/UModelerX/DrawVertexProcedural"
{
    Properties
    {
        _VertexSize("VertexSize", Float) = 2.5
        [Enum(UnityEngine.Rendering.CompareFunction)] _ZTest("ZTest", Float) = 0
    }
    SubShader
    {
        Tags
        {
            "RenderType" = "Opaque"
            "LightMode" = "Always"
            "UModelerXPicker" = "VertexID"
        }
        LOD 100

        Lighting Off
        // 화면 정렬 사각형이라 어느 면이 앞인지 의미가 없습니다.
        Cull Off

        CGINCLUDE
        #include "UnityCG.cginc"
        #include "UModelerX.cginc"

        /// 점 하나 = 화면 공간 사각형(정점 6개). CPU 는 사각형을 만들지 않습니다.
        /// 슬롯 = 정점 ID 라 인덱스 버퍼도, 토폴로지 버퍼도 필요 없습니다 —
        /// 점당 데이터는 색 하나(4바이트)뿐입니다.
        StructuredBuffer<float3> _UMXPointPositions;
        /// RGBA32. 알파 0 은 "그리지 않음"(죽었거나 숨겨진 정점)입니다.
        StructuredBuffer<uint> _UMXPointColors;

        float _VertexSize;

        /// 클립 공간 w 는 카메라 앞쪽 거리라 이 값 아래면 뒤에 있습니다.
        static const float UMXPointNearW = 1e-4;

        struct UMXPointVaryings
        {
            float4 pos : SV_POSITION;
            float4 color : COLOR;
            nointerpolation uint pointID : TEXCOORD0;
        };

        UMXPointVaryings UMXPointVert(uint vertexID)
        {
            uint pointID = vertexID / 6;
            uint corner = vertexID - pointID * 6;

            /// 오브젝트 행렬은 C# 이 GL 모델뷰에 실어 보내므로 여기서는 VP 만 곱합니다.
            float4 clipPos = mul(UNITY_MATRIX_VP, float4(_UMXPointPositions[pointID], 1.0));
            float4 color = UMXUnpackColor32(_UMXPointColors[pointID]);

            UMXPointVaryings output;
            output.color = color;
            output.pointID = pointID;

            /// 기존 지오메트리 경로와 같은 깊이 보정입니다.
            clipPos.z += clipPos.w * _VertexSize * 0.00002;

            /// 사각형 여섯 정점: (-,-) (+,-) (-,+) / (-,+) (+,-) (+,+)
            float cornerX = ((corner == 1) || (corner == 4) || (corner == 5)) ? 1.0 : -1.0;
            float cornerY = ((corner == 2) || (corner == 3) || (corner == 5)) ? 1.0 : -1.0;

            /// 크기 규약도 기존과 같습니다 — 한쪽 반경이 _VertexSize/2 픽셀, 전체 폭이 _VertexSize.
            float2 offset = float2(_VertexSize / _ScreenParams.x, _VertexSize / _ScreenParams.y)
                * clipPos.w * float2(cornerX, cornerY);
            clipPos.xy += offset;

            /// 알파 0(죽음/숨김)이거나 카메라 뒤면 여섯 정점을 한 점으로 모아 면적을 0 으로 만듭니다.
            /// 알파만 0 으로 두면 픽셀은 그대로 래스터되므로 채우기 비용이 남습니다.
            bool skip = (color.a <= 0.0) || (clipPos.w < UMXPointNearW);
            output.pos = skip
                ? mul(UNITY_MATRIX_VP, float4(_UMXPointPositions[pointID], 1.0))
                : clipPos;
            return output;
        }
        ENDCG

        Pass
        {
            Name "VertexRectProcedural"

            Blend One OneMinusSrcAlpha
            ZWrite On
            ZTest [_ZTest]

            CGPROGRAM
            /// 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag

            UMXPointVaryings vert(uint vertexID : SV_VertexID) { return UMXPointVert(vertexID); }

            float4 frag(UMXPointVaryings input) : SV_Target
            {
                return input.color;
            }
            ENDCG
        }

        Pass
        {
            Name "VertexRectProceduralId"

            /// ID 는 섞으면 안 됩니다. 클리어(0) 위에 그대로 덮어씁니다.
            Blend Off
            ZWrite On
            ZTest LEqual

            CGPROGRAM
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag

            UMXPointVaryings vert(uint vertexID : SV_VertexID) { return UMXPointVert(vertexID); }

            float4 frag(UMXPointVaryings input) : SV_Target
            {
                /// 슬롯이 곧 정점 ID 라 피킹 ID 를 버퍼에 저장하지 않습니다.
                return UMXEncodeElemID(input.pointID + 1);
            }
            ENDCG
        }
    }
}
