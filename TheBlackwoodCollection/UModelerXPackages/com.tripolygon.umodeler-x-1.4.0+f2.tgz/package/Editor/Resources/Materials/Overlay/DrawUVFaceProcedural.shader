﻿Shader "Hidden/UModelerX/DrawUVFaceProcedural"
{
    Properties
    {
        /// 겹침 상한용 스텐실 상태. C# 이 패스마다 갈아끼웁니다(EditorMeshesBase.SetupUVFace*Pass).
        /// 스텐실 블록이 읽으므로 Properties 에 선언되어 있어야 합니다.
        /// 기본값은 "스텐실을 쓰지 않음" 입니다 — 상한이 꺼져 있으면 이 상태 그대로 그립니다.
        _UVFaceStencilRef("Stencil Ref", Float) = 255
        _UVFaceStencilComp("Stencil Comp", Float) = 8
        _UVFaceStencilOp("Stencil Op", Float) = 0
        /// 1 이면 선택·하이라이트 페이스만 그립니다(우선 패스).
        _UVFacePriorityOnly("Priority Only", Float) = 0
        _UVFacePrioritySelected("Priority Selected Color", Color) = (0,0,0,0)
        _UVFacePriorityHighlight("Priority Highlight Color", Color) = (0,0,0,0)
    }
    SubShader
    {
        Tags
        {
            "RenderType" = "Opaque"
            "LightMode" = "Always"
        }
        LOD 100

        Blend SrcAlpha OneMinusSrcAlpha
        Lighting Off
        ZWrite Off
        ZTest Always

        Cull Off
        Offset -1, -1

        /// 픽셀당 겹침 상한을 스텐실로 셉니다. 상태는 C# 이 패스마다 지정합니다.
        ///  - 우선 패스(선택·하이라이트): Always / Replace / Ref 255 — 상한 없이 그리고 픽셀을 점유.
        ///  - 일반 패스: Greater / IncrSat / Ref N — 스텐실값이 N 보다 적을 때만 통과하고 1 올립니다.
        ///    우선 패스가 255 로 점유한 픽셀은 N > 255 가 거짓이라 통과하지 못합니다.
        ///  - 상한이 꺼져 있으면 Always / Keep 이라 스텐실이 아무 일도 하지 않습니다.
        Stencil
        {
            Ref [_UVFaceStencilRef]
            Comp [_UVFaceStencilComp]
            Pass [_UVFaceStencilOp]
        }

        Pass
        {
            Name "UVFaceProcedural"

            CGPROGRAM
            /// 버텍스 단계에서 StructuredBuffer 를 읽으므로 4.5 가 필요합니다.
            #pragma target 4.5
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            #include "UModelerX.cginc"

            /// 삼각형 하나 = 정점 3개. 삼각형 수가 면마다 달라 정점 ID 에서 면 ID 를 유도할 수
            /// 없으므로 토폴로지가 루프 인덱스를 직접 담습니다. UV 와 색은 그 인덱스로 찾습니다.
            StructuredBuffer<float2> _UMXUVFaceUVs;
            /// 삼각형 코너의 루프 인덱스. 삼각화 수명.
            StructuredBuffer<uint3> _UMXUVFaceTopology;
            /// 루프별 색(RGBA32). 알파 0 은 "그리지 않음"입니다.
            StructuredBuffer<uint> _UMXUVFaceColors;

            struct UMXUVFaceVaryings
            {
                float4 pos : SV_POSITION;
                float4 color : COLOR;
            };

            float _UVFacePriorityOnly;
            float4 _UVFacePrioritySelected;
            float4 _UVFacePriorityHighlight;

            /// 선택·하이라이트 색인가. 색은 Color32 로 양자화되어 들어오고 C# 도 같은 양자화를
            /// 거쳐 넘기므로, 서로 다른 색은 최소 1/255(≈0.0039) 만큼 떨어져 이 허용치로 갈립니다.
            /// 한 페이스의 세 코너가 같은 색이라 보간해도 값이 그대로여서 프래그먼트에서 판정합니다.
            bool UMXUVFaceIsPriority(float4 color)
            {
                return all(abs(color - _UVFacePrioritySelected) < 0.001)
                    || all(abs(color - _UVFacePriorityHighlight) < 0.001);
            }

            UMXUVFaceVaryings vert(uint vertexID : SV_VertexID)
            {
                uint triangleIndex = vertexID / 3;
                uint corner = vertexID - triangleIndex * 3;

                uint3 triangleLoops = _UMXUVFaceTopology[triangleIndex];
                /// 동적 인덱싱이 안 되는 곳이 있어 선택으로 풀어씁니다.
                uint loopIndex = corner == 0 ? triangleLoops.x
                    : (corner == 1 ? triangleLoops.y : triangleLoops.z);

                UMXUVFaceVaryings output;
                /// UVToPos 가 UV 를 클립 좌표로 옮깁니다(w = 1, z = 0.5).
                output.pos = UVToPos(_UMXUVFaceUVs[loopIndex]);
                output.color = UMXUnpackColor32(_UMXUVFaceColors[loopIndex]);
                return output;
            }

            float4 frag(UMXUVFaceVaryings input) : SV_Target
            {
                /// 알파 0 은 "그리지 않음" 규약입니다. 블렌드 결과는 어차피 같지만
                /// 버리지 않으면 겹침 카운트를 한 장 먹으므로 여기서 걷어냅니다.
                clip(input.color.a - 0.001);
                /// 우선 패스는 선택·하이라이트만 남깁니다. 일반 패스(_UVFacePriorityOnly = 0)는
                /// 우선 패스가 스텐실로 점유한 픽셀에서 이미 막히므로 여기서 거를 필요가 없습니다.
                clip(_UVFacePriorityOnly * (UMXUVFaceIsPriority(input.color) ? 1.0 : -1.0));
                return input.color;
            }
            ENDCG
        }
    }
}
